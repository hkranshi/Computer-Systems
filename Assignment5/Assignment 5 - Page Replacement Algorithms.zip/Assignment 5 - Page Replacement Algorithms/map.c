#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <sys/resource.h>
#include <math.h>
#include <limits.h>

static size_t page_size;

// align_down - rounds a value down to an alignment
// @x: the value
// @a: the alignment (must be power of 2)
//
// Returns an aligned value.
#define align_down(x, a) ((x) & ~((typeof(x))(a) - 1))

#define AS_LIMIT (1 << 25) // Maximum limit on virtual memory bytes
#define MAX_SQRTS (1 << 27) // Maximum limit on sqrt table entries
static double *sqrts;
// A copy variable to store the address of the current page
double* sqrts_allocated = NULL;
void *addr, *data;
// Number of pages to be stored in memory
int N;
int clock_hand = 0;
long i_temp;
size_t fault_count = 0;

typedef enum {
  FIFO,
  LRU,
  CLOCK
} page_repl_algo;

// struct for maintaining the page table
typedef struct {
  void* page_start;
  int hit;
  int flag;
} page_table_t;

page_table_t* table;

// Use this helper function as an oracle for square root values.
static void
calculate_sqrts(double *sqrt_pos, int start, int nr)
{
  int i;

  for (i = 0; i < nr; i++) {
    sqrt_pos[i] = sqrt((double)(start + i));
  }
}

static int find_msb(size_t l) {
  int pos = 0;
  while(l >>= 1) {
    pos ++;
  }
  return pos;
} 

static bool find_and_update(void* addr) { 
    int i; 
    for(i = 0; i < N; i++) {
      if(table[i].page_start == addr) { 
        // Mark that the page deserves a second chance 
        table[i].flag = 1; 
        // Return 'true', that is there was a hit 
        // and so there's no need to replace any page 
        return true; 
      } 
    }
    // Return 'false' so that a page for replacement is selected 
    // as he reuested page doesn't exist in memory 
    return false;
}

// Updates the page in memory and returns the pointer 
static int replace_and_update(void* addr, int pointer) 
{ 
  while(true) {    
    // We found the page to replace 
    if(!table[pointer].flag) { 
      // if a page is already mapped, unmap it
      if(table[pointer].page_start != NULL)
        munmap(table[pointer].page_start, page_size);
      // Replace with new page 
      table[pointer].page_start = mmap(addr, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANONYMOUS, -1, 0);
      // Fill the page with data
      calculate_sqrts(table[pointer].page_start, ((unsigned long)addr - (unsigned long)sqrts) / sizeof(double), page_size / sizeof(double));
      // give chance to the page newly allocated
      table[pointer].flag = true;
      // Return updated pointer 
      return (pointer + 1) % N; 
    } 
    // Mark it 'false' as it got one chance 
    // and will be replaced next time unless accessed again 
    table[pointer].flag = false; 
    //Pointer is updated in round robin manner 
    pointer = (pointer + 1) % N; 
  } 
} 

static void free_pages() {
  for(int i = 0;i < N;i ++) {
    if(table[i].page_start != NULL)
    {  munmap(table[i].page_start, page_size);
      table[i].page_start=NULL;
      table[i].flag=0;
      table[i].hit=0;
    }  
  }
 
 
} 

static void
fifo_sigsegv_handler(int sig, siginfo_t* si, void* ctx){
  fault_count+=1;
   uintptr_t fault_addr = (uintptr_t)si->si_addr;
  // find the position of MSB in page_size
  int msb_page_size = find_msb(page_size);
  // find the starting address of the page
  uintptr_t page_start = (fault_addr ^ (fault_addr & ((1L << msb_page_size) - 1)));
  // if a page is already mapped, unmap it
  for(int i=0;i<N;i++){
  	if(table[i].flag==1){
  	int j=(i+1)%N;
  	table[i].flag=0;
  	table[j].flag=1;
  	if(table[j].page_start!=NULL)
  	munmap(table[j].page_start, page_size);
  	table[j].page_start=mmap((void*)page_start, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANONYMOUS, -1, 0);
  	  calculate_sqrts(table[j].page_start, (page_start - (unsigned long)sqrts) / sizeof(double), page_size / sizeof(double));
  	  break;
  	}
  	if(table[i].page_start==NULL){
  	table[i].flag=1;
  	table[i].page_start=mmap((void*)page_start, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANONYMOUS, -1, 0);
  	  calculate_sqrts(table[i].page_start, (page_start - (unsigned long)sqrts) / sizeof(double), page_size / sizeof(double));
  	  break;
  	}
  	table[i].flag=0;
  }
}

static void
lru_sigsegv_handler(int sig, siginfo_t* si, void* ctx){
  fault_count+=1;
	long min=LONG_MAX,k;
   uintptr_t fault_addr = (uintptr_t)si->si_addr;
  // find the position of MSB in page_size
  int msb_page_size = find_msb(page_size);
  // find the starting address of the page
  uintptr_t page_start = (fault_addr ^ (fault_addr & ((1L << msb_page_size) - 1)));
  // if a page is already mapped, unmap it
 // printf("%ld\n", (page_start - (unsigned long)sqrts) / sizeof(double));
 //52058624
  for(int i=0;i<N;i++){
  	if(table[i].hit==0)
  	{
  	table[i].hit=i_temp;
  	table[i].page_start=mmap((void*)page_start, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANONYMOUS, -1, 0);
  	  calculate_sqrts(table[i].page_start, (page_start - (unsigned long)sqrts) / sizeof(double), page_size / sizeof(double));
  	  break;
  	
  	}
  		
  }
 // printf("%ld\n", (page_start - (unsigned long)sqrts) / sizeof(double));
  
  //#############
 // printf("%ld\n",table[k].flag);
 //printf("%p\n",table[k].page_start);
  //############
    for(int i=0;i<N;i++){
  if(min>table[i].hit){
  	min=table[i].hit;
  	k=i;
  	}
  	}
 table[k].hit=i_temp;
 munmap(table[k].page_start, page_size);
  table[k].page_start=mmap((void*)page_start, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANONYMOUS, -1, 0);
  	  calculate_sqrts(table[k].page_start, (page_start - (unsigned long)sqrts) / sizeof(double), page_size / sizeof(double));
  	  
}

static void
clock_sigsegv_handler(int sig, siginfo_t* si, void* ctx){
  uintptr_t fault_addr = (uintptr_t)si->si_addr;
  // find the position of MSB in page_size
  int msb_page_size = find_msb(page_size);
  // find the starting address of the page
  void* page_start = (void*)(fault_addr ^ (fault_addr & ((1L << msb_page_size) - 1)));
  if(!find_and_update(page_start)) { 
    // Selects and updates a victim page 
    clock_hand = replace_and_update(page_start, clock_hand); 
    // Update page faults 
    fault_count ++; 
  }
}

static void
register_fifo_handler() {
  struct sigaction act;

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = fifo_sigsegv_handler;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up FIFO SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
register_lru_handler() {
  struct sigaction act;

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = lru_sigsegv_handler;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up FIFO SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
register_clock_handler() {
  struct sigaction act;

  // Register a signal handler to capture SIGSEGV.
  act.sa_sigaction = clock_sigsegv_handler;
  act.sa_flags = SA_SIGINFO;
  sigemptyset(&act.sa_mask);
  if (sigaction(SIGSEGV, &act, NULL) == -1) {
    fprintf(stderr, "Couldn't set up FIFO SIGSEGV handler;, %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
setup_sqrt_region()
{
  struct rlimit lim = {AS_LIMIT, AS_LIMIT};

  // Only mapping to find a safe location for the table.
  sqrts = mmap(NULL, MAX_SQRTS * sizeof(double) + AS_LIMIT, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (sqrts == MAP_FAILED) {
    fprintf(stderr, "Couldn't mmap() region for sqrt table; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Now release the virtual memory to remain under the rlimit.
  if (munmap(sqrts, MAX_SQRTS * sizeof(double) + AS_LIMIT) == -1) {
    fprintf(stderr, "Couldn't munmap() region for sqrt table; %s\n",
            strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Set a soft rlimit on virtual address-space bytes.
  if (setrlimit(RLIMIT_AS, &lim) == -1) {
    fprintf(stderr, "Couldn't set rlimit on RLIMIT_AS; %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

static void
random_access(double* sqrts, int test_count) {
  int i, pos = rand() % (MAX_SQRTS - 1);
  double correct_sqrt;
  //table = malloc(N * (sizeof(page_table_t)));

  printf("Validating square root table contents...\n\n");
  srand(0xDEADBEEF);

  for (i = 0; i < test_count; i++) {
    if (i % 2 == 0)
      pos = rand() % (MAX_SQRTS - 1);
    else
      pos += 1;
    addr=&sqrts[pos];
    int msb_page_size = find_msb(page_size);
      
  // find the starting address of the page
    data =  (void*)((unsigned long)addr ^ ((unsigned long)addr & ((1L << msb_page_size) - 1)));
    for(int j=0;j<N;j++){
    	if(table[j].page_start==data)
    	table[j].hit=i+1;
    }
    i_temp=i+1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }
}

static void
linear_access(double* sqrts, int test_count) {
  int i, pos;
  double correct_sqrt;
  //table = malloc(N * (sizeof(page_table_t)));

  for (i = 0; i < test_count; i++) {
    pos = i % (MAX_SQRTS - 1);
    addr=&sqrts[pos];
    int msb_page_size = find_msb(page_size);
    data =  (void*)((unsigned long)addr ^ ((unsigned long)addr & ((1L << msb_page_size) - 1)));
    for(int j=0;j<N;j++){
    	if(table[j].page_start==data)
    	table[j].hit=i+1;
    }
    i_temp=i+1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }
}

static void
strided_linear_access(double* sqrts, int test_count, int stride) {
  int i, pos;
  double correct_sqrt;
  //table = malloc(N * (sizeof(page_table_t)));
	
  for (i = 0; i < test_count; i+=stride) {
    pos = i % (MAX_SQRTS - 1);
    addr=&sqrts[pos];
  int msb_page_size = find_msb(page_size);
   data =  (void*)((unsigned long)addr ^ ((unsigned long)addr & ((1L << msb_page_size) - 1)));
    for(int j=0;j<N;j++){
    	if(table[j].page_start==data)
    	table[j].hit=i+1;
    }
    i_temp=i+1;
    calculate_sqrts(&correct_sqrt, pos, 1);
    if (sqrts[pos] != correct_sqrt) {
      fprintf(stderr, "Square root is incorrect. Expected %f, got %f.\n",
              correct_sqrt, sqrts[pos]);
      exit(EXIT_FAILURE);
    }
  }
}

static void
printSummary() {
  size_t start, end;
  printf("Pages in Memory at the end: \n");
  for(int i = 0; i < N;i ++) {
    start = ((unsigned long)table[i].page_start - (unsigned long)sqrts) / sizeof(double);
    end = start + page_size / sizeof(double); 
  printf("Page no: %d \t  start address: %p \t end address: %p\n",i, table[i].page_start,table[i].page_start+page_size-sizeof(double) );
    printf("Page no: %d \t  start number: %ld \t end number: %ld\n",i, start, end);
    
    
  }
  printf("\n");
 
}

static void
test_sqrt_region(void)
{
  random_access(sqrts, 500000);
  printf("Hit count for Random Access: %ld\n",500000-fault_count);
  printf("Fault Count for Random Access: %ld\n", fault_count);
  printSummary();
  free_pages();
  fault_count = 0;
  linear_access(sqrts, 50000000);
    printf("Hit count for Random Access: %ld\n",50000000-fault_count);
  printf("Fault Count for Linear Access: %ld\n", fault_count);
  printSummary();
  fault_count = 0;
   free_pages();
   
 
  strided_linear_access(sqrts, 50000000, 1000);
    printf("Hit count for Random Access: %ld\n",50000-fault_count);
  printf("Fault Count for Strided Linear Access: %ld\n", fault_count);
  printSummary();
  fault_count = 0;
   free_pages();
 
  printf("All tests passed!\n");
}

static void
run_tests_for(page_repl_algo algo) {
  fault_count = 0;
  table = malloc(N * (sizeof(page_table_t)));
  switch (algo) {
    case FIFO:
      register_fifo_handler();
      break;
    case LRU:
      register_lru_handler();
      break;
    case CLOCK:
      register_clock_handler();
      break;
    default:
      fprintf(stderr, "Unknown Page replacement algorithm, exiting...");
      break;
  }
  test_sqrt_region();
 // free(table);
}

int
main(int argc, char *argv[])
{
  if(argc != 2) {
    printf("Usage: ./mmap <NUM_FRAMES>");
    exit(1);
  }
  N = atoi(argv[1]);
  page_size = sysconf(_SC_PAGESIZE);
  printf("page_size is %ld\n", page_size);
  setup_sqrt_region();
  printf("FIFO:\n");
  run_tests_for(FIFO);
  printf("LRU:\n");
  run_tests_for(LRU);
  printf("CLOCK:\n");
  run_tests_for(CLOCK);
  return 0;
}
