/*
Name-Anshika Saxena
Id-23210018@iitgn.ac.in
 
*/
#include "cachelab.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include <stdbool.h>
#include <limits.h>


typedef struct 
{
    unsigned tag;   //it store the tag for each cacheline in the cache
    bool valid;     //it check the data present in cacheLine is valid or not.
    long long line; //it store the unique id of the data which is mapped to that particular cacheLine. Using this we perform LRU     
}cacheline;         //structure to store the meta data for each cache line which include tag, valid bit , uniqueId.
cacheline* cache;
int inputCmdLine;
int s;             // Set Index bits
int S;             // Total Sets
int E;             // Associativity for cache set
int b;             // The block offset bits
char *fileName;    // Trace File name
int hit;           //count total number of hit occur 
int miss;	    //count total number of miss occur 
int evict;         //count total number of eviction occur 
long long unique_idOfInstruction;                         //generate unique id for each Data  
FILE *ptrFile;                                            //Pointer to trace file
int readCmdLineArguments(int argc, char** argv);          //This reads command line args
int readFromFile();                                       //This reads from trace file
void datamodify(unsigned address);       		  //Performs modify operation
void dataLoad(unsigned address);            		  //Performs load operation
void dataStore(unsigned address);          		  //Performs store operation
void setUpTheCache();                     		  //Allocates memory for cache
void freeTheCache();

int main(int argc, char** argv)
{
    int validArg;                                        //Checks the validity of commmand line arguments
    validArg=readCmdLineArguments(argc,  argv);
    if(validArg==0)
    {
        exit(1);                                          //Invalid Arguments;so exit
    }

    S=1<<s;
    setUpTheCache();
    ptrFile = fopen (fileName,"r");  			  //Open File for reading and take the instructions
    if(ptrFile==NULL)
    {
        exit(1); 					 //Invalid File;so exit
    }
    readFromFile();
  freeTheCache();
    printSummary(hit,miss,evict);
    return(0);
}

/*
* Purpose: It reads from cmd line and stores the result in s,E,b,fileName
* It returns 1 if all the arguments are valid
* It returns 0 if atleast one of them is not valid
*/
int readCmdLineArguments(int argc, char** argv)
{
    fileName = NULL;
    /* Looping over arguments
    * Reference: Recitation 05
    */
    while((inputCmdLine = getopt(argc, argv, "s:E:b:t:v"))!=-1)
    {
    
        /* Determine which argument it is processing */
        switch(inputCmdLine)
        {
        case 's':
            s=atoi(optarg);
            break;
        case 'E':
            E=atoi(optarg);
            break;
        case 'b':
            b=atoi(optarg);
            break;
        case 't':
            fileName=optarg;
            break;
        case 'v':
            //Verbosity is on
            break;
        default:
            //Wrong Argument
            exit(1);
        }
    } // End of while
    if(s==0 || E==0 || b==0 || fileName==NULL)
    {
        return(0);
    }
    else
    {
        return(1);
    }
}


/*
* Purpose: It reads from file and sets the program to work
* It returns 1 if all the arguments are valid
* It returns 0 if atleast one of them is not valid
*/
int readFromFile()
{
    char operationType;
    unsigned address;
    int size;

    /* Looping over arguments and reading lines like "M 20,1"
    * Reference: Recitation 05
    */
    while(fscanf(ptrFile,"%c %x,%d", &operationType, &address, &size)>0)
    {
     unique_idOfInstruction+=1;
        if(operationType=='M')
        { 
        
            datamodify(address);
        }
        else if(operationType=='L')
        { 
            dataLoad(address);
        }
        else if(operationType=='S')
        { 
            dataStore(address);
        }
        else
        {
            //Unwanted input
        }

    }
    fclose(ptrFile); // Close file when done
    return(0);
}

/*
* Purpose:
* 1. The function checks for presence in the set
* 2. If present, it ensures that it is seen that
*    it was accessed recently via linked list
* 3. If not, it adds it to the set and
*    3.1. By evicting LRU one if full
*    3.2. 
*/
void dataLoad(unsigned address)
{
long set=(address>>b)&((-1<<s)^-1);   		//calculate the set number
long tag=(address>>(s+b));	      		//calculate the tag 
for(int k=0;k<E;k++){
	if(cache[set*E+k].valid==false){	//check the valid bit on the mapped cacheLine  if valid is false then 
		miss++;
		cache[set*E+k].valid=true;    	//update all the information about the address in the cacheLine metadata and load data 
		cache[set*E+k].tag=tag;
		cache[set*E+k].line=unique_idOfInstruction;
		break;
	}
	if(cache[set*E+k].valid==true){
		if(cache[set*E+k].tag==tag){
			cache[set*E+k].line=unique_idOfInstruction;  //if data is already in cache then hit occur  
			hit++;					     // update the unique id of instruction 
			break;
		}
		else
		{
			if(k==E-1)				    //cache set is full and data is not in cache means miss happen 
				{
				long long num=LONG_MAX;		    //used to get the lower id data so we replace and load new data.
				long tempSet;			    //to store set number and block number of cache where eviction occur.
				long block;
				for(int k=0;k<E;k++){
					   if(cache[set*E+k].line<=num){  //get the lowest id data and replace with new data
						num=cache[set*E+k].line;
						tempSet=set;
						block=k;
			        	    }
				}
				evict++;
				miss++;
				cache[tempSet*E+block].tag=tag;            //update the metadata of new address which is now store in 
				cache[tempSet*E+block].line=unique_idOfInstruction;  //particular cacheLine
			}
		}
	}
}    
}

/*
* dataStore and dataLoad can be considered to do the same here.
* So, it transfers control to dataLoad
*/
void dataStore(unsigned address)
{
    dataLoad(address);
}

/*
* datamodify can be interpreted as dataLoad and then
* incrementing the hit.
*/
void datamodify(unsigned address)
{
    dataLoad(address);
    hit++;
}


/*
* Purpose: setUpTheCache does the following:
* 1. It allocate a bunch of memory using malloc of whole cache Size so that only one time malloc called. 
* 2. Now check that we get a requested memory or not if not then simply exit.
  3. Allocated memory divided into array of the cacheline.
* 4. Assign the valid bit of each cache line is false because initially cache is empty or some garbage data .
	It not contain any valid data.
*/
void setUpTheCache()
{
    int i;
    cache= ( cacheline*)malloc(S*E* sizeof(cacheline)); 
    if(cache==NULL)
    {
        exit(0);
    }
    for(i=0; i<S*E; i++)
    {
        cache[i].valid=false;
    }
}
//Deallocate the memory in end so that next time we can reuse this and memory leakage not occur. 
void freeTheCache()
{
  
    free(cache);
}

