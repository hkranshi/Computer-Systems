#!/usr/bin/env python

from mininet.net import Mininet
from mininet.node import Controller, RemoteController, OVSController
from mininet.node import CPULimitedHost, Host, Node
from mininet.node import OVSKernelSwitch, UserSwitch
from mininet.topo import Topo
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import TCLink, Intf
from subprocess import call
import argparse

class LinuxRouter(Node):

    # pylint: disable=arguments-differ
    def config( self, **params ):
        super( LinuxRouter, self).config( **params )
        # Enable forwarding on the router
        self.cmd( 'sysctl net.ipv4.ip_forward=1' )

    def terminate( self ):
        self.cmd( 'sysctl net.ipv4.ip_forward=0' )
        super( LinuxRouter, self ).terminate()

class myNetwork(Topo):
    
    def build(self):
        print( '*** Add switches\n')
        r1 = self.addHost('r1', cls=LinuxRouter, ip='10.0.1.1/24', ipv6 = False)
        # net['r1'].cmd('sysctl -w net.ipv4.ip_forward=1')
        r2 = self.addHost('r2', cls=LinuxRouter, ip='10.0.2.1/24', ipv6 = False)
        # net['r2'].cmd('sysctl -w net.ipv4.ip_forward=1')
        r3 = self.addHost('r3', cls=LinuxRouter, ip='10.0.3.1/24', ipv6 = False)
        # net['r3'].cmd('sysctl -w net.ipv4.ip_forward=1')
        s4 = self.addSwitch('s4')
        s5 = self.addSwitch('s5')
        s6 = self.addSwitch('s6')
        s7 = self.addSwitch('s7')

        print( '*** Add hosts\n')
        h1 = self.addHost('h1', cls=Host, ip='10.0.1.12/24', defaultRoute='via 10.0.1.1', ipv6 = False)
        h2 = self.addHost('h2', cls=Host, ip='10.0.1.23/24', defaultRoute='via 10.0.1.1', ipv6 = False)
        h3 = self.addHost('h3', cls=Host, ip='10.0.2.34/24', defaultRoute='via 10.0.2.1', ipv6 = False)
        h4 = self.addHost('h4', cls=Host, ip='10.0.2.45/24', defaultRoute='via 10.0.2.1', ipv6 = False)
        h5 = self.addHost('h5', cls=Host, ip='10.0.3.56/24', defaultRoute='via 10.0.3.1', ipv6 = False)
        h6 = self.addHost('h6', cls=Host, ip='10.0.3.67/24', defaultRoute='via 10.0.3.1', ipv6 = False)

        print( '*** Add links\n')
        self.addLink(h1, s4, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(h2, s4, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(r1, s4, params1={ 'ip' : '10.0.1.1/24' }, cls=TCLink, **{'bw':4,'delay':4})
        self.addLink(h3, s5, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(h4, s5, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(r2, s5, params1={ 'ip' : '10.0.2.1/24' }, cls=TCLink, **{'bw':4,'delay':4})
        self.addLink(s6, h6, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(s6, h5, cls=TCLink, **{'bw':2,'delay':2})
        self.addLink(r3, s6, params1={ 'ip' : '10.0.3.1/24' }, cls=TCLink, **{'bw':4,'delay':4})
        self.addLink(r1, s7, intfName1='r1-eth-s', params1={ 'ip' : '10.0.4.10/24' }, cls=TCLink, **{'bw':10,'delay':2})
        self.addLink(r2, s7, intfName1='r2-eth-s', params1={ 'ip' : '10.0.4.11/24' }, cls=TCLink, **{'bw':10,'delay':2})
        self.addLink(r3, s7, intfName1='r3-eth-s', params1={ 'ip' : '10.0.4.12/24' }, cls=TCLink, **{'bw':10,'delay':2})

def run_network(args):
    net = Mininet(topo=myNetwork(),waitConnected=True,cleanup=True)
    net.start()

    cmd_str = f'tcpdump -i {net["r1"].intfNames()[0]} -w {args.filename}.pcap &'
    # print(cmd_str)
    net['r1'].cmd(cmd_str)

    print(net['r1'].cmd('ip route add 10.0.2.0/24 via 10.0.4.11 dev r1-eth-s'))
    # print(net['r1'].cmd('ip route add 10.0.3.0/24 via 10.0.4.12 dev r1-eth-s'))
    print(net['r2'].cmd('ip route add 10.0.1.0/24 via 10.0.4.10 dev r2-eth-s'))
    print(net['r2'].cmd('ip route add 10.0.3.0/24 via 10.0.4.12 dev r2-eth-s'))
    # print(net['r3'].cmd('ip route add 10.0.1.0/24 via 10.0.4.10 dev r3-eth-s'))
    print(net['r3'].cmd('ip route add 10.0.2.0/24 via 10.0.4.11 dev r3-eth-s'))

    if args.config == 'c':
        print(net['r1'].cmd('ip route add 10.0.3.0/24 via 10.0.4.11 dev r1-eth-s'))
        print(net['r3'].cmd('ip route add 10.0.1.0/24 via 10.0.4.11 dev r3-eth-s'))
    elif args.config == 'b':
        print(net['r1'].cmd('ip route add 10.0.3.0/24 via 10.0.4.12 dev r1-eth-s'))
        print(net['r3'].cmd('ip route add 10.0.1.0/24 via 10.0.4.10 dev r3-eth-s'))
    
    print(net.pingAllFull())
    print()
    print("Table @ r1")
    print(net['r1'].cmd('route'))
    print("Table @ r2")
    print(net['r2'].cmd('route'))
    print("Table @ r3")
    print(net['r3'].cmd('route'))

    print(f"route h1 -> h6 for ({args.config})\n" + net['h1'].cmd('traceroute', net['h6'].IP()))
    print(net['h1'].cmd(f'ping -c 10 {net["h6"].IP()}'))
    net['h6'].cmd('iperf -sD')
    print(net['h1'].cmd(f'iperf -c {net["h6"].IP()} -i 1'))

    # CLI(net)
    net['r1'].cmd('pkill -SIGINT tcpdump')
    net['h6'].cmd('pkill -SIGINT iperf')
    net.stop()

if __name__ == '__main__':
    setLogLevel( 'info' )
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('--config',type=str,choices=['b','c'],required=True)
    arg_parser.add_argument('--filename',type=str,required=True)
    args = arg_parser.parse_args()
    run_network(args)