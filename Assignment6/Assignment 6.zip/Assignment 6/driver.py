# driver code for assignment 6

from subprocess import Popen, PIPE

print("*** Running Part I ***")

process1 = Popen(['sudo', 'python3', 'topo1.py', '--config', 'b', '--filename', './dumps/part1b_dump'],stdout=PIPE)
process1.wait()
std_out, std_err = process1.communicate()
print(std_out.decode())
process2 = Popen(['sudo', 'python3', 'topo1.py', '--config', 'c', '--filename', './dumps/part1c_dump'],stdout=PIPE)
process2.wait()
std_out, std_err = process2.communicate()
print(std_out.decode())

print("*** Running Part II ***")
for algo in ['vegas', 'reno', 'cubic', 'bbr']:
    print(f"*** Running Congestion Control: {algo.upper()} ***")
    process1 = Popen(['sudo', 'python3', 'topo2.py', '--config', 'b', '--filename', f'/dumps/part2b_{algo}_dump', '--cc', algo],stdout=PIPE)
    process1.wait()
    std_out, std_err = process1.communicate()
    print(std_out.decode())
    process2 = Popen(['sudo', 'python3', 'topo2.py', '--config', 'c', '--filename', f'/dumps/part2c_{algo}_dump', '--cc', algo],stdout=PIPE)
    process2.wait()
    std_out, std_err = process2.communicate()
    print(std_out.decode())
    process3 = Popen(['sudo', 'python3', 'topo2.py', '--config', 'b', '--filename', f'/dumps/part2d_{algo}_dump1', '--cc', algo, '--loss', '1'],stdout=PIPE)
    process3.wait()
    std_out, std_err = process3.communicate()
    print(std_out.decode())
    process4 = Popen(['sudo', 'python3', 'topo2.py', '--config', 'b', '--filename', f'/dumps/part2d_{algo}_dump3', '--cc', algo, '--loss', '3'],stdout=PIPE)
    process4.wait()
    std_out, std_err = process4.communicate()
    print(std_out.decode())
    print()