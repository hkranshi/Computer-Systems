#!/usr/bin/env python

from mininet.net import Mininet
from mininet.node import Controller, RemoteController, OVSController
from mininet.node import CPULimitedHost, Host, Node
from mininet.node import OVSKernelSwitch, UserSwitch
from mininet.node import IVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import TCLink, Intf
from subprocess import call
import argparse
from time import sleep

def myNetwork(args):

    net = Mininet( topo=None,
                   build=False,
                   cleanup=True,
                   ipBase='10.0.0.0/8')

    print( '*** Adding controller\n' )
    c0=net.addController(name='c0',
                      controller=OVSController,
                      protocol='tcp',
                      port=6633)

    print( '*** Add switches\n')
    s1 = net.addSwitch('s1', cls=OVSKernelSwitch, failMode='standalone')
    s2 = net.addSwitch('s2', cls=OVSKernelSwitch, failMode='standalone')

    print( '*** Add hosts\n')
    h1 = net.addHost('h1', cls=Host, ip='10.0.0.1', defaultRoute=None)
    h2 = net.addHost('h2', cls=Host, ip='10.0.0.2', defaultRoute=None)
    h3 = net.addHost('h3', cls=Host, ip='10.0.0.3', defaultRoute=None)
    h4 = net.addHost('h4', cls=Host, ip='10.0.0.4', defaultRoute=None)

    print( '*** Add links\n')
    net.addLink(h1, s1, cls=TCLink, **{'bw':2,'delay':2})
    net.addLink(h2, s1, cls=TCLink, **{'bw':2,'delay':2})
    net.addLink(s1, s2, cls=TCLink, **{'bw':8,'delay':2,'loss': args.loss})
    net.addLink(s2, h3, cls=TCLink, **{'bw':2,'delay':2})
    net.addLink(s2, h4, cls=TCLink, **{'bw':2,'delay':2})

    print( '*** Starting network\n')
    net.build()
    print( '*** Starting controllers\n')
    for controller in net.controllers:
        controller.start()

    print( '*** Starting switches\n')
    net.get('s1').start([])
    net.get('s2').start([])

    print( '*** Post configure switches and hosts\n')

    cmd_str = f'tcpdump -i s2-eth3 -w {args.filename}.pcap &'
    print(cmd_str+'\n')
    s1.cmdPrint(cmd_str)
    # CLI(net)
    if args.config == 'b':
        h4.cmdPrint('iperf -sD')
        print(h1.cmdPrint(f'iperf -c {h4.IP()} -Z {args.cc}'))
        sleep(15)
    elif args.config == 'c':
        h4.cmdPrint('iperf -sD -P 3')
        print(h1.cmdPrint(f'iperf -c {h4.IP()} -t 20 -Z {args.cc} &'))
        print(h2.cmdPrint(f'iperf -c {h4.IP()} -t 20 -Z {args.cc} &'))
        print(h3.cmdPrint(f'iperf -c {h4.IP()} -t 20 -Z {args.cc} &'))
        sleep(25)
    s1.cmdPrint('pkill -SIGINT tcpdump')
    h4.cmdPrint('pkill -SIGINT iperf')
    net.stop()

if __name__ == '__main__':
    setLogLevel( 'info' )
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('--config',type=str,choices=['b','c'],required=True)
    arg_parser.add_argument('--loss',type=int,default=0)
    arg_parser.add_argument('--cc',type=str,choices=['vegas','reno','cubic','bbr'],required=True)
    arg_parser.add_argument('--filename',type=str,required=True)
    args = arg_parser.parse_args()
    myNetwork(args)